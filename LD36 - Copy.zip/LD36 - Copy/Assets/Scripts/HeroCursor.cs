﻿using UnityEngine;
using System.Collections;

public class HeroCursor : MonoBehaviour {

	public Transform heroTrans;
	public float cursorSpeed = 0.5f;

	public float xMax = 20f;
	public float yMax = 13f;

	float x = 0;
	float y = 0;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void LateUpdate () {
		float mouseX = Input.GetAxisRaw("Mouse X") * cursorSpeed;
		float mouseY = Input.GetAxisRaw("Mouse Y") * cursorSpeed;

		x += mouseX;
		y += mouseY;

		x = Mathf.Clamp(x, -xMax, xMax);
		y = Mathf.Clamp(y, -yMax, yMax);

		Vector3 newPos = new Vector3(heroTrans.position.x + x, 0.5f, heroTrans.position.z + y);

		transform.position = newPos; //+= (newPos - transform.position) * 0.4f;
									 //Cursor.lockState = CursorLockMode.Locked;

		Cursor.lockState = CursorLockMode.Locked;
		Cursor.visible = false;
	}
}

﻿using UnityEngine;
using System.Collections;

public class EnemyHealth : MonoBehaviour {

	public float stunTimer = 0;
	public int healthStuff = 5;

	public GameObject deathFX;
	public Transform dizzyFX;

	public Renderer graphicsQuad;

	Color myColor;

	public int HealthStuff
	{
		get { return healthStuff; }
		set
		{ healthStuff = value;
			if (healthStuff <= 0)
			{
				// you dead
				DEATH();
			}
		}
	}

	EnemyMovement movement;

	// Use this for initialization
	void Start () {
		movement = GetComponent<EnemyMovement>();
		myColor = Color.black;
	}
	
	// Update is called once per frame
	void Update () {
		if (stunTimer > 0)
		{
			stunTimer -= Time.deltaTime;
		}
		dizzyFX.transform.localScale = Vector3.one * Mathf.Clamp(stunTimer, 0, 1.5f);
		dizzyFX.transform.localRotation = Quaternion.Euler(45, 0, Time.time * 650);


		myColor = Color.Lerp(myColor, Color.black, Time.deltaTime * 10f);

		graphicsQuad.material.SetColor("_EmissionColor", myColor);
	}

	public void Damage(int h, float s)
	{
		HealthStuff -= h;
		stunTimer += s;
		movement.stunTimer += s;
		myColor = Color.red;
	}

	void DEATH()
	{
		GameObject go = Instantiate(deathFX, transform.position, Quaternion.identity) as GameObject;
		Destroy(graphicsQuad.transform.parent.gameObject);
		Destroy(gameObject);
	}
}

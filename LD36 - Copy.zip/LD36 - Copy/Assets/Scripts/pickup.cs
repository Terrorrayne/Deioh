﻿using UnityEngine;
using System.Collections;

public class pickup : MonoBehaviour
{

	public GameObject message;

	bool displayIt = false;

	public GameObject player;

	// Use this for initialization
	void Start()
	{

	}

	// Update is called once per frame
	void Update()
	{
		message.SetActive(displayIt);
	}

	void OnTriggerStay(Collider other)
	{
		print(other);
		if (other.gameObject == player)
		{
			if (Input.GetKey(KeyCode.Space))
			{
				// shield is held
				displayIt = false;

				Vector3 dir = GameManager.self.heroCusor.transform.position - GameManager.self.heroMovement.transform.position;
				dir.y = 0;

				dir.Normalize();

				transform.parent.position = player.transform.position + (dir * 0.6f);
			}
			else
			{
				// display a message
				displayIt = true;
			}
		}

	}

	void OnTriggerExit(Collider other)
	{


		displayIt = false;
	}
}

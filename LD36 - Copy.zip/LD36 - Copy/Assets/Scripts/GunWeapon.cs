﻿using UnityEngine;
using System.Collections;

public class GunWeapon : MonoBehaviour {

	public float knockbackPush = 10f;

	float chargeMeter = 0f;

	HeroMovement hero;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetMouseButton(0))
		{
			//SHOOTTHEGUN

			chargeMeter += Time.deltaTime;
		}

		if (Input.GetMouseButtonUp(0)) // RMB release
		{
			chargeMeter = 0;
		}
	}
}

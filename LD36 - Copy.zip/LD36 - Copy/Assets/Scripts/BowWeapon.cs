﻿using UnityEngine;
using System.Collections;

public class BowWeapon : MonoBehaviour
{

	public GameObject arrowObject;
	public AnimationCurve speedCurve;
	public float knockbackPush = 10f;

	float bowMeter = 0f;

	HeroMovement hero;

	// Use this for initialization
	void Start()
	{
		hero = GetComponentInParent<HeroMovement>();
	}

	// Update is called once per frame
	void Update()
	{

		if (Input.GetKey(KeyCode.Space))
		{

		}
		else
		{


			if (Input.GetMouseButton(1)) // if RMB
			{
				bowMeter += Time.deltaTime;

				//Camera.main.GetComponent<Camera>().fieldOfView = 40 + Mathf.Clamp(bowMeter, 0, 2) * 10f;
			}

			if (Input.GetMouseButtonUp(1)) // RMB release
			{
				// check bowMeter
				if (bowMeter > 0.1f) // either we shoot, or we don't
				{
					// get the dir to shoot
					Vector3 dir = GameManager.self.heroCusor.transform.position - GameManager.self.heroMovement.transform.position;
					dir.y = 0;

					Quaternion rot = Quaternion.LookRotation(dir);

					GameObject go = Instantiate(arrowObject, transform.position, rot) as GameObject;
					go.GetComponent<Arrow>().speed = speedCurve.Evaluate(bowMeter);

					// stun for .4 sec
					int h = 0;
					float s = 1f;

					if (bowMeter > 0.5f)
					{
						// do 1 damage
						// stun for .7 sec
						h = 1;
						s = 2f;

						if (bowMeter > 1)
						{
							// do 2 damage
							// stun for 1 sec
							h = 2;
							s = 3.5f;
						}
					}
					go.GetComponent<Arrow>().damageHealth = h;
					go.GetComponent<Arrow>().damageStun = s;


					// apply knockback to player
					hero.Push(dir.normalized * (0.25f + Mathf.Clamp01(bowMeter)) * -knockbackPush);
				}

				bowMeter = 0f; //reset
			}
		}
	}
}

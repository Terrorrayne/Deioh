﻿using UnityEngine;
using System.Collections;

public class EnemyGun : MonoBehaviour
{

	public GameObject bullet;
	public EnemyMovement move;

	// Use this for initialization
	void Start()
	{
		move = GetComponent<EnemyMovement>();
	}

	// Update is called once per frame
	void Update()
	{

	}

	public void SHOOT(float randomness, Vector3 targetPosition)
	{
		if (move.stunTimer < 0) // only shoot if you arn't stunned
		{
			// get player position
			// get dir
			Vector3 dir = targetPosition - transform.position;
			// add randomness
			dir = dir.normalized + Random.insideUnitSphere * randomness;

			dir.y = 0;

			Quaternion rot = Quaternion.LookRotation(dir);

			// create bullet
			GameObject go = Instantiate(bullet, transform.position, rot) as GameObject;
		}


	}
}

﻿using UnityEngine;
using System.Collections;

public class TreeScaler : MonoBehaviour {

	public float maxX = 1;
	public float minX = 1;
	public float maxY = 1;
	public float minY = 1;

	float swaySmoothing = 2f;

	float y = 0;

	// Use this for initialization
	void Start () {
		float x = Random.Range(minX, maxX);
		float y = Random.value;

		swaySmoothing = 1 - y;

		y = y * (maxY - minY) + minY;

		float sign = Mathf.Sign(Random.Range(-1, 1));

		transform.localScale = new Vector3(x * sign, y, y);

	}

	void Update()
	{
		y = Mathf.Lerp(y, GameManager.targetY, Time.deltaTime * swaySmoothing);

		transform.rotation = Quaternion.Euler(0, y, 0);
	}



}

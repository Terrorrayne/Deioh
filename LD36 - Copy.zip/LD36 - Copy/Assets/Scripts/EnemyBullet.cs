﻿using UnityEngine;
using System.Collections;

public class EnemyBullet : MonoBehaviour
{

	public float lifeTime = 1f;
	public float speed = 10f;

	// Use this for initialization
	void Start()
	{
		StartCoroutine(KillYoSelf(lifeTime));
	}

	// Update is called once per frame
	void Update()
	{
		transform.Translate(Vector3.forward * Time.deltaTime * speed);
	}

	IEnumerator KillYoSelf(float time)
	{
		yield return new WaitForSeconds(time);
		Destroy(gameObject);
	}

	void OnTriggerEnter(Collider other)
	{
		if (!other.CompareTag("Enemy") && !other.CompareTag("GameController"))
		{
			if (other.CompareTag("Player"))
			{
				other.GetComponent<HeroHealth>().Damage();
			}
			Destroy(gameObject);

		}
	}
}

﻿using UnityEngine;
using System.Collections;

public class ENMYGFX : MonoBehaviour {

	Transform mydad;
	Vector3 offset;

	// Use this for initialization
	void Start () {
		mydad = transform.parent;
		offset = transform.localPosition;
		transform.parent = null;
	}
	
	// Update is called once per frame
	void Update () {
		transform.position = mydad.position + offset;
	}
}

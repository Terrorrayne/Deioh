﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {

	public static GameManager self;

	public HeroCursor heroCusor;
	public HeroMovement heroMovement;
	public Light dirLight;

	public static float targetY;

	public GameObject IntroScreen;
	public GameObject WinScreen;

	// Use this for initialization
	void Start () {
		if (self != this)
			self = this;

		StartCoroutine(Sway());
		StartCoroutine(DisplayAndFade(IntroScreen));
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown(KeyCode.R))
		{
			SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
		}

		dirLight.transform.position += new Vector3(2f * Time.deltaTime, 0, 0.3f * Time.deltaTime);

		if (Input.GetKeyDown(KeyCode.Escape))
		{
			//exit game
			Application.Quit();
		}
	}

	IEnumerator Sway()
	{
		while (true)
		{
			yield return new WaitForSeconds(Random.Range(.5f, 1.2f));
			targetY = Random.Range(-20, 20);
		}
	}

	IEnumerator DisplayAndFade(GameObject thingy)
	{
		thingy.SetActive(true);
		yield return new WaitForSeconds(7);
		thingy.SetActive(false);
	}

	public void WIN()
	{
		//you win
		WinScreen.SetActive(true);
	}
}

﻿using UnityEngine;
using System.Collections;

public class Arrow : MonoBehaviour {

	public float lifeTime = 1f;
	public float speed = 10f;

	public float damageStun = 1f;
	public int damageHealth = 1;

	// Use this for initialization
	void Start () {
		StartCoroutine(KillYoSelf(lifeTime));
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate(Vector3.forward * Time.deltaTime * speed);
	}

	IEnumerator KillYoSelf (float time)
	{
		yield return new WaitForSeconds(time);
		Destroy(gameObject);
	}

	void OnTriggerEnter(Collider other)
	{
		if (!other.CompareTag("Player") && !other.CompareTag("GameController"))
		{
			if (other.CompareTag("Enemy"))
			{
				other.GetComponent<EnemyHealth>().Damage(damageHealth, damageStun);
			}
			Destroy(gameObject);
		}
	}
}

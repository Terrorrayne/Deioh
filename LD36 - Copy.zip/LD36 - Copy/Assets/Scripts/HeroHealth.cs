﻿using UnityEngine;
using System.Collections;

public class HeroHealth : MonoBehaviour {

	public GameObject gameoverScreen;
	public Transform heathbar;
	Vector3 startingScale;

	int hits = 10;

	// Use this for initialization
	void Start () {
		gameoverScreen.SetActive(false);
		startingScale = heathbar.localScale;
	}

	// Update is called once per frame
	void Update () {
	
	}

	public void Damage()
	{
		hits--;
		hits = Mathf.Clamp(hits, 0, 10);
		heathbar.localScale = (new Vector3((hits / 10f) * startingScale.x, startingScale.y, startingScale.z));

		if (hits <= 0)
		{
			// you died
			// STOP MOVING
			Destroy(GetComponent<HeroMovement>());
			// tell gui
			gameoverScreen.SetActive(true);
		}
	}

	public void HealthItem()
	{
		hits += 2;
		hits = Mathf.Clamp(hits, 0, 10);
		heathbar.localScale = (new Vector3((hits / 10f) * startingScale.x, startingScale.y, startingScale.z));

	}
}

﻿using UnityEngine;
using System.Collections;

public class Weapon : MonoBehaviour {

	public float knockbackPush = 10f;

	float bowMeter = 0f;

	HeroMovement hero;

	// Use this for initialization
	void Start () {
		hero = GetComponentInParent<HeroMovement>();
	}

	// Update is called once per frame
	void Update () {
	
	}
}

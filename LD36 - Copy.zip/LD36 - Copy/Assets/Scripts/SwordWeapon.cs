﻿using System.Collections;
using UnityEngine;

public class SwordWeapon : MonoBehaviour
{

	public float knockbackPush = 10f;
	public GameObject swordshashFX;

	float chargeMeter = 0f;

	bool attacking = false;
	int damageHealth;

	HeroMovement hero;

	// Use this for initialization
	void Start()
	{
		hero = GetComponentInParent<HeroMovement>();

	}

	// Update is called once per frame
	void Update()
	{
		if (Input.GetKey(KeyCode.Space))
		{

		}
		else
		{


			if (Input.GetMouseButton(0)) // if RMB
			{
				chargeMeter += Time.deltaTime;

				//Camera.main.GetComponent<Camera>().fieldOfView = 40 + Mathf.Clamp(chargeMeter, 0, 2) * 10f;

				// shield with the sword
			}

			if (Input.GetMouseButtonUp(0)) // RMB release
			{
				// get the dir to shoot
				Vector3 dir = GameManager.self.heroCusor.transform.position - GameManager.self.heroMovement.transform.position;
				dir.y = 0;

				Quaternion rot = Quaternion.LookRotation(dir);
				transform.rotation = rot;

				// spawn fx using the same rotation
				GameObject fx = Instantiate(swordshashFX, transform.position, rot, transform) as GameObject;
				Destroy(fx, 0.6f);

				// apply knockback to player
				hero.Push(dir.normalized * (0.1f + Mathf.Clamp01(chargeMeter)) * knockbackPush);


				damageHealth = 1;
				if (chargeMeter > 0.5f)
				{
					damageHealth = 3;
					if (chargeMeter > 1f)
					{
						damageHealth = 5;

					}
				}

				StartCoroutine(AttackSequence(chargeMeter));

				chargeMeter = 0f; //reset
			}
		}

	}

	IEnumerator AttackSequence(float charge)
	{
		attacking = true;
		yield return new WaitForSeconds(.15f);
		attacking = false;
	}

	void OnTriggerEnter(Collider other)
	{
		if (attacking)
		{
			if (!other.CompareTag("Player") && !other.CompareTag("GameController"))
			{
				if (other.CompareTag("Enemy"))
				{
					other.GetComponent<EnemyHealth>().Damage(damageHealth, 0);
				}
			}
		}

	}
}

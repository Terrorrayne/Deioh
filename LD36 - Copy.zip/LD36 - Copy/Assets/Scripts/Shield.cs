﻿using UnityEngine;
using System.Collections;

public class Shield : MonoBehaviour {

	public GameObject target;
	public GameObject bullets;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnTriggerEnter(Collider other)
	{
		if (other.CompareTag("Bullets"))
		{
			Destroy(other.gameObject);
		}
	}


	void OnTriggerStay(Collider other)
	{
		if (other.gameObject == target)
		{
			GameManager.self.WIN();
		}
	}

}

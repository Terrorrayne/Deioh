﻿using UnityEngine;
using System.Collections;

public class HeroMovement : MonoBehaviour
{

	public float moveSpeed = 10f;
	public float knockbackRecoverySpeed = 10f;

	public Transform heroSprite;

	Vector3 latentVel = Vector3.zero;
	public float animFrequency = 2;
	public float animAmplitude = 10f;

	// Use this for initialization
	void Start()
	{

	}

	// Update is called once per frame
	void Update()
	{
		float h = Input.GetAxisRaw("Horizontal");
		float v = Input.GetAxisRaw("Vertical");

		Vector3 move = new Vector3(h, 0, v);

		wobbleAnim(Mathf.Clamp01(move.magnitude));

		Vector3 dir = move.normalized;
		move = Mathf.Clamp01(move.magnitude) * dir * Time.deltaTime * moveSpeed;

		if (Input.GetKey(KeyCode.Space))
		{
			move *= 0.75f;
		}
		else
		{
			if (Input.GetMouseButton(0))
			{
				move *= 0.5f;
			}
		}



		// add throwback vel
		move += latentVel;
		latentVel = Vector3.Lerp(latentVel, Vector3.zero, Time.deltaTime * knockbackRecoverySpeed);

		transform.Translate(move);
	}

	void wobbleAnim(float spd)
	{
		float wobble = Mathf.Cos(Time.time * animFrequency);
		heroSprite.localEulerAngles = new Vector3(60, 0, animAmplitude * wobble * spd);
		wobble = Mathf.Sin(Time.time * animFrequency);
		heroSprite.localPosition = new Vector3(0, Mathf.Abs(wobble) * spd * 0.25f, 0);
	}

	public void Push(Vector3 vel) // used to add throwback from weapon recoil/enemies
	{
		latentVel += vel;
	}

}
